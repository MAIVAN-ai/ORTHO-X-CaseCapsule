# Case Capsule Overview

**Case:** Synthetic proximal femur fracture 001  
**Capsule:** `cc-synth-pff-001`

A fictional 78-year-old previously independent woman sustained a right pertrochanteric proximal femur
fracture after a fall from standing.

Initial radiographic interpretation produced a provisional AO/OTA 31-A2.2 assertion. Additional
synthetic CT evidence led to a revised 31-A2.3 assertion, which superseded the first and was confirmed
by a fictional surgeon.

The synthetic care pathway then records operative fixation with a cephalomedullary nail, a small
postoperative seroma captured using the DISH domains, progressive rehabilitation, and linked
patient-centred and functional outcomes through three months.

The example demonstrates the ORTHO-X principle:

> **Evidence → reasoning → confirmation → intervention → events → rehabilitation → outcomes**

without erasing prior states.
