# Case Capsule Index

## Core
- [`../manifest.json`](../manifest.json)
- [`overview.md`](overview.md)
- [`../clinical/current-state.md`](../clinical/current-state.md)
- [`../clinical/timeline.md`](../clinical/timeline.md)

## Evidence
- [`../raw/evidence-manifest.json`](../raw/evidence-manifest.json)

## Assertions
- [`../skills/01-case-intake.assertion.json`](../skills/01-case-intake.assertion.json)
- [`../skills/04-aoota-classification-v1.assertion.json`](../skills/04-aoota-classification-v1.assertion.json)
- [`../skills/04-aoota-classification-v2.assertion.json`](../skills/04-aoota-classification-v2.assertion.json)
- [`../skills/07-treatment-mapping.assertion.json`](../skills/07-treatment-mapping.assertion.json)
- [`../skills/surgical-event.assertion.json`](../skills/surgical-event.assertion.json)
- [`../skills/dish-sso.assertion.json`](../skills/dish-sso.assertion.json)
- [`../skills/11-rehab.assertion.json`](../skills/11-rehab.assertion.json)
- [`../skills/recovery-trajectory.assertion.json`](../skills/recovery-trajectory.assertion.json)

## Outcomes
- [`../outcomes/outcome-observations.json`](../outcomes/outcome-observations.json)

## Provenance
- [`../provenance/events.jsonl`](../provenance/events.jsonl)
