# Synthetic Proximal Femur Fracture Case Capsule

**Example ID:** `cc-synth-pff-001`  
**Status:** Synthetic reference implementation  
**Clinical domain:** Proximal femur fracture / orthopaedic trauma  
**Purpose:** Demonstrate a longitudinal ORTHO-X Case Capsule from referral through outcome measurement.

> [!WARNING]
> **All patient, clinician, institution, device and event data in this example are fictional.**
> This example is for software architecture, testing and education only. It is not medical advice,
> a validated clinical pathway, a regulatory claim, or a substitute for clinician review.

---

## Narrative

A fictional 78-year-old woman presents after a low-energy fall with acute right hip pain and inability
to bear weight.

The Case Capsule follows:

```text
Referral
  ↓
Initial imaging
  ↓
Preliminary AO/OTA assertion
  ↓
CT / additional evidence
  ↓
Superseding AO/OTA assertion + surgeon confirmation
  ↓
Treatment mapping
  ↓
Cephalomedullary nail fixation
  ↓
Postoperative DISH-domain wound surveillance
  ↓
Rehabilitation
  ↓
ICHOM-aligned patient-centred and functional outcomes
  ↓
Recovery-trajectory assessment
```

The example is intentionally designed to show that Case Capsule history is **not overwritten**.
The initial fracture classification is retained after being superseded by a later interpretation.

---

## Synthetic patient context

| Field | Synthetic value |
| --- | --- |
| Age | 78 years |
| Sex | Female |
| Mechanism | Low-energy fall from standing |
| Side | Right |
| Pre-injury mobility | Independent community ambulation, no walking aid |
| Living situation | Lives independently |
| Main goal | Return home and resume independent walking |
| Key comorbidity context | Hypertension; osteoporosis risk noted |
| Direct identifiers | None |

---

## Longitudinal flow

### 1. Referral

The referral records:

- fall from standing;
- inability to bear weight;
- externally rotated painful right lower limb;
- no reported head injury;
- pre-injury independent ambulation.

The source is represented by `ev-referral-001`.

### 2. Imaging

Initial AP pelvis and lateral hip imaging supports an unstable pertrochanteric fracture.

The first AI-assisted classification assertion is:

```text
AO/OTA 31-A2.2
confidence: 0.87
status: pending-confirmation
```

Additional CT/imaging evidence then changes the interpretation to:

```text
AO/OTA 31-A2.3
confidence: 0.94
status: clinician-confirmed
supersedes: as-aoota-001
```

The first assertion remains in the Capsule as historical provenance.

### 3. Treatment

The Treatment Mapping Skill records an educationally framed treatment assertion supporting operative
fixation as the selected pathway after clinician review.

The synthetic clinical team selects a **cephalomedullary nail**.

### 4. Surgery

The synthetic operative event records:

- closed reduction;
- cephalomedullary nail fixation;
- fluoroscopic confirmation;
- no intraoperative complication recorded;
- postoperative weight bearing as tolerated in the fictional care plan.

The Case Capsule stores this as a structured surgical-event assertion linked to the operative-note
evidence reference.

### 5. DISH-domain surgical-site surveillance

The example records a small postoperative **seroma** identified during wound review.

For demonstration purposes:

- dehiscence: not observed;
- infection: not observed;
- seroma: observed, small, managed conservatively;
- haematoma: not observed.

This example deliberately does **not** invent or reproduce a formal DISH grade. It demonstrates how
the four DISH domains can be captured as structured surgical-site outcome evidence and linked to later
patient outcomes.

### 6. Rehabilitation

The synthetic rehabilitation trajectory includes:

- mobilization beginning postoperatively;
- walker-assisted ambulation at discharge;
- progressive outpatient/home physiotherapy;
- transition to a single walking aid;
- independent indoor ambulation by the three-month follow-up.

### 7. ICHOM-aligned outcomes

The example uses an illustrative subset of patient-centred domains aligned with ICHOM Major Injury
principles:

- pain;
- musculoskeletal / ambulatory function;
- activities of daily living / autonomy;
- physical/global health.

It also includes a performance measure (Timed Up and Go) to demonstrate linkage of patient-reported
and functional outcomes.

> This is an **ICHOM-aligned demonstration**, not a claim that the example implements every mandatory
> variable, instrument or timepoint of an official ICHOM Standard Set.

---

## Files

```text
synthetic-proximal-femur-001/
├── README.md
├── manifest.json
├── raw/
│   └── evidence-manifest.json
├── clinical/
│   ├── timeline.md
│   └── current-state.md
├── skills/
│   ├── 01-case-intake.assertion.json
│   ├── 04-aoota-classification-v1.assertion.json
│   ├── 04-aoota-classification-v2.assertion.json
│   ├── 07-treatment-mapping.assertion.json
│   ├── surgical-event.assertion.json
│   ├── dish-sso.assertion.json
│   ├── 11-rehab.assertion.json
│   └── recovery-trajectory.assertion.json
├── outcomes/
│   └── outcome-observations.json
├── provenance/
│   └── events.jsonl
└── capsule/
    ├── index.md
    └── overview.md
```

---

## Architectural points demonstrated

1. **Authoritative evidence and derived assertions remain distinct.**
2. **New evidence may supersede an earlier interpretation without deleting it.**
3. **Human confirmation is represented explicitly.**
4. **Treatment and surgical execution are linked to prior reasoning.**
5. **Postoperative surgical-site events are captured separately from causal attribution.**
6. **Rehabilitation and outcomes extend the Case Capsule beyond discharge.**
7. **Patient-centred outcomes are connected back to baseline and intervention.**
8. **The frontier model is not the durable object — the Case Capsule is.**
