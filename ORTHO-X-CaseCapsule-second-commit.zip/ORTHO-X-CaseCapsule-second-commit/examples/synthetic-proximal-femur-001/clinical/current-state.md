# Current State — Synthetic PFF 001

**As of:** 2026-04-11  
**Synthetic example only**

## Current accepted fracture classification

- AO/OTA: **31-A2.3**
- Status: clinician-confirmed
- Supersedes: `as-aoota-001` (31-A2.2)
- Evidence: synthetic radiographs + CT

## Treatment / intervention

- Operative fixation selected
- Synthetic procedure: closed reduction and cephalomedullary nail fixation
- No intraoperative complication recorded in the synthetic operative note

## Surgical-site outcome

DISH-domain recording at postoperative wound review:

- Dehiscence: not observed
- Infection: not observed
- Seroma: small, observed, managed conservatively
- Haematoma: not observed

No formal DISH grade is claimed in this example.

## Rehabilitation

At six weeks:

- recovery progressing;
- single walking aid outdoors;
- short indoor distances without aid;
- continuing therapy.

At three months:

- substantial functional improvement;
- residual limitation with longer community ambulation.

## Outcomes

Illustrative patient-centred / functional outcome state:

- pain: 8/10 acute baseline → 3/10 at six weeks → 1/10 at three months;
- Timed Up and Go: unable to perform acutely → 21.4 s at six weeks → 14.8 s at three months;
- basic ADL: independent at three months in this synthetic scenario;
- global physical health: patient reports improvement.

The recovery-trajectory assertion remains **pending clinician confirmation**.
