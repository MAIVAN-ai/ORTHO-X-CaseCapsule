# Clinical Timeline — Synthetic PFF 001

| Date/time | Event | Evidence / assertion | State |
| --- | --- | --- | --- |
| 2026-01-10 08:10 | Referral after fall | `ev-referral-001` | Source evidence |
| 2026-01-10 09:02 | AP pelvis + lateral hip imaging | `ev-xray-001` | Source evidence |
| 2026-01-10 09:20 | Preliminary AO/OTA classification | `as-aoota-001` = 31-A2.2 | Superseded |
| 2026-01-10 11:15 | Additional CT evidence | `ev-ct-001` | Source evidence |
| 2026-01-10 11:40 | Revised AO/OTA classification | `as-aoota-002` = 31-A2.3 | Confirmed |
| 2026-01-10 13:20 | Treatment pathway confirmed | `as-treatment-001` | Confirmed |
| 2026-01-11 | Cephalomedullary nail fixation | `as-surgery-001` | Confirmed |
| 2026-01-15 | Surgical-site review | `as-dish-001` | Small seroma; confirmed |
| 2026-02-22 | Six-week rehab review | `as-rehab-001` | Progressing |
| 2026-04-11 | Three-month outcomes | `outcomes/outcome-observations.json` | Recorded |
| 2026-04-11 | Recovery-trajectory interpretation | `as-trajectory-001` | Pending confirmation |

## Key provenance demonstration

`as-aoota-001` is intentionally retained despite being superseded by `as-aoota-002`.

This allows a reviewer to reconstruct **what the system believed at each point in time and why it changed**.
