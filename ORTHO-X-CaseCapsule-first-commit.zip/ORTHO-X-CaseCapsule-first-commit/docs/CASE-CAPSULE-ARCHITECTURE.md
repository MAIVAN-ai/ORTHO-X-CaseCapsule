# ORTHO-X Case Capsule Architecture

**Status:** Draft v0.1  
**Purpose:** Define the architectural boundaries and invariants of the ORTHO-X Case Capsule.

---

## 1. Definition

An **ORTHO-X Case Capsule** is a persistent, longitudinal, provenance-aware representation of a
patient's orthopaedic journey.

It is not the legal source-of-truth medical record and does not replace authoritative systems such as
the EHR, PACS/VNA, FHIR server, laboratory system, registry or surgical video archive.

Instead, it provides a durable bridge between:

1. authoritative clinical evidence;
2. structured clinical assertions;
3. human confirmation;
4. clinical decisions and interventions;
5. longitudinal functional and patient-centred outcomes; and
6. model-independent agent/Skill execution.

---

## 2. Architectural objective

The Case Capsule exists to prevent each AI invocation from reconstructing the patient from scratch.

It transforms a sequence of disconnected clinical encounters into a persistent evidence graph:

```text
Evidence
  ↓
Assertions
  ↓
Reconciliation
  ↓
Decisions
  ↓
Interventions
  ↓
Events
  ↓
Recovery
  ↓
Outcomes
```

Each link must remain traceable to source evidence and provenance.

---

## 3. System boundaries

### 3.1 Authoritative source systems

The following remain authoritative for their original data:

- EHR / EMR
- FHIR servers
- PACS/VNA and DICOM archives
- LIS
- RIS
- theatre documentation systems
- surgical video stores
- implant/device systems
- rehabilitation systems
- registry systems
- patient-reported outcome platforms

A Case Capsule SHOULD reference source-system identifiers and cryptographic hashes where feasible.

It MUST NOT silently alter the source evidence.

### 3.2 Case Capsule persistence layer

The persistence layer contains or references:

- source evidence metadata;
- source-object pointers;
- hashes/checksums;
- normalized clinical events;
- structured assertions;
- clinician confirmations;
- supersession relationships;
- treatment/intervention events;
- outcomes;
- provenance events;
- integrity status.

### 3.3 OrthoSkills reasoning layer

OrthoSkills consume Case Capsule state and produce structured outputs.

An OrthoSkill MUST NOT treat its own prior output as authoritative evidence merely because it already
exists in the Capsule.

### 3.4 OrthoFlow orchestration layer

OrthoFlow coordinates:

- which Skill runs;
- when it runs;
- what evidence it may access;
- which outputs require review;
- which downstream workflow is triggered;
- when outcome capture is due.

### 3.5 Analytics and learning layer

Permissioned downstream views may support:

- clinical quality improvement;
- benchmarking;
- PMCF;
- RWE;
- research;
- registry reporting;
- value-based healthcare;
- federated learning.

This downstream use MUST respect the data rights and governance attached to the source Case Capsule.

---

## 4. Canonical object model

A minimal Case Capsule contains:

### Case Capsule

Identity and lifecycle metadata for the longitudinal container.

### Evidence Reference

Pointer to or representation of authoritative source evidence.

### Clinical Assertion

A model-, Skill- or human-generated interpretation derived from evidence.

### Provenance Event

Append-only record of who/what performed an operation and against which state.

### Outcome Observation

Clinical, functional or patient-reported observation at a defined timepoint.

### Human Confirmation

A specialized provenance event recording clinician review or confirmation.

### Relationship

Traceable link such as:

- derived-from
- supports
- contradicts
- supersedes
- confirms
- caused-by
- followed-by
- outcome-of

---

## 5. Evidence versus assertion

The separation between evidence and assertions is a hard architectural invariant.

### Evidence example

```text
DICOM Study UID: 1.2.840...
Acquired: 2026-09-03T10:22:00+02:00
Modality: CR
Source system: PACS
```

### Assertion example

```text
AO/OTA classification: 31-A2.3
Confidence: 0.94
Produced by: ao-ota-classification skill v1.0
Derived from: DICOM study ...
Confirmation status: confirmed
```

The classification is not part of the original radiograph. It is a derived assertion.

---

## 6. Longitudinal state

The Case Capsule SHOULD support two simultaneous views:

### 6.1 Current state

The best currently accepted understanding of the case.

### 6.2 Historical state

All prior assertions, confirmations, corrections and supersessions.

Current-state material MAY be optimized for agent readability.

Historical provenance MUST remain inspectable.

---

## 7. Supersession

New evidence frequently changes clinical interpretation.

Supersession MUST be explicit.

Example:

```text
assertion A
"31-A2.2"
status = superseded
        │
        │ superseded_by
        ▼
assertion B
"31-A2.3"
status = confirmed
```

A superseded assertion MUST NOT be physically deleted solely because it is no longer current.

---

## 8. Outcome attribution

The Case Capsule SHOULD link outcomes to the care trajectory rather than treat outcomes as isolated
measurements.

Conceptually:

```text
baseline
  ↓
clinical state
  ↓
decision
  ↓
intervention
  ↓
postoperative event
  ↓
rehabilitation exposure
  ↓
follow-up measurement
  ↓
patient-centred outcome
```

Outcome attribution may remain uncertain. The schema therefore distinguishes observations from causal
claims.

No automated system SHOULD infer causality solely from temporal sequence.

---

## 9. Storage model

The specification is storage-engine agnostic.

A deployment MAY use:

- files/Markdown/JSON for a reference implementation;
- object storage;
- relational databases;
- graph databases;
- FHIR repositories;
- event stores;
- hybrid approaches.

The portable Case Capsule contract is more important than any particular database.

### Recommended pattern

```text
Authoritative source object
      │
      ├── source identifier
      ├── hash
      └── access policy
             │
             ▼
      Case Capsule reference
             │
             ▼
       structured assertion
             │
             ▼
       provenance events
```

---

## 10. Suggested reference directory

```text
case-capsule/
├── CASE-CAPSULE-SCHEMA.md
├── manifest.json
├── raw/
│   └── source-reference manifests
├── clinical/
│   ├── timeline.md
│   ├── current-state.md
│   ├── diagnoses.md
│   ├── classifications.md
│   └── treatment-history.md
├── skills/
│   └── structured Skill outputs
├── outcomes/
│   ├── clinical/
│   ├── functional/
│   └── patient-reported/
├── provenance/
│   └── events.jsonl
└── capsule/
    ├── index.md
    └── overview.md
```

This is a reference layout, not a requirement for production deployment.

---

## 11. Case Capsule Integrity Check

An Integrity Check SHOULD identify:

- invalid schema objects;
- broken evidence references;
- hash mismatches;
- assertions without supporting evidence;
- contradictory active assertions;
- missing supersession links;
- stale pending confirmations;
- clinically important missing fields;
- incomplete baseline or follow-up outcome data;
- inconsistent patient/case identifiers;
- provenance discontinuities.

Integrity checks MUST distinguish:

- technical inconsistency;
- missing data;
- clinical disagreement.

Clinical disagreement MUST NOT be automatically "fixed" by deleting one interpretation.

---

## 12. Security and privacy principles

A production deployment SHOULD implement:

- minimum-necessary access;
- role-based authorization;
- patient/case scoping;
- encryption in transit and at rest;
- append-only or tamper-evident provenance;
- pseudonymisation/de-identification where appropriate;
- explicit export controls;
- retention and deletion policies;
- auditability of agent access;
- hospital-controlled deployment where required.

Case Capsule identifiers SHOULD NOT embed direct patient identifiers.

---

## 13. Interoperability direction

Future versions SHOULD define mappings to relevant standards, including where appropriate:

- HL7 FHIR;
- DICOM/DICOMweb;
- SNOMED CT;
- LOINC;
- ICD;
- UDI/device identifiers;
- ICHOM-aligned outcome structures.

External classification content MUST respect applicable intellectual-property and licensing terms.

---

## 14. Model independence

No schema field SHOULD require a single model provider.

Model provenance should record enough information to identify the execution environment without
coupling the Capsule format to a vendor.

Examples:

- provider
- model family
- model/version identifier
- runtime
- Skill name/version
- prompt/configuration digest where permitted

---

## 15. Non-goals

v0.1 does not define:

- a replacement EHR;
- an autonomous diagnostic system;
- a complete FHIR implementation;
- a medical-device regulatory classification;
- a universal causal inference engine;
- patient consent rules for every jurisdiction;
- ownership of clinical data;
- commercial rights to downstream evidence.

---

## 16. Architectural invariant

The shortest statement of the ORTHO-X Case Capsule architecture is:

> **Source evidence remains authoritative; reasoning becomes structured assertions; every material
> assertion remains traceable; humans can confirm or supersede it; outcomes close the longitudinal loop.**
