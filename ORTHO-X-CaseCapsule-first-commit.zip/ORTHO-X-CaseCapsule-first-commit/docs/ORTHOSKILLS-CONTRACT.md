# OrthoSkills ↔ Case Capsule Contract

**Status:** Draft v0.1  
**Purpose:** Define how model-independent OrthoSkills read from and write to an ORTHO-X Case Capsule.

---

## 1. Contract

Every OrthoSkill follows:

```text
READ → REASON → ASSERT → CITE → CONFIRM → WRITE
```

The Skill does not own the patient's memory. The Case Capsule does.

The Skill does not redefine source evidence. It interprets source evidence and emits structured
assertions.

---

## 2. Inputs

An OrthoSkill MAY receive:

- Case Capsule manifest;
- relevant source evidence references;
- selected current-state assertions;
- relevant historical assertions;
- patient goals/preferences when authorized;
- terminology/context resources;
- external evidence/guideline references;
- orchestration parameters.

An OrthoSkill SHOULD receive the minimum necessary data for the task.

---

## 3. Required Skill behavior

A clinically material OrthoSkill MUST:

1. identify the task and target clinical object;
2. distinguish evidence from existing assertions;
3. identify missing required inputs;
4. reason according to the Skill specification;
5. express uncertainty when appropriate;
6. emit structured outputs;
7. cite supporting Case Capsule evidence;
8. declare human-confirmation requirements;
9. avoid silent modification of prior assertions;
10. preserve provenance.

---

## 4. Output object

The primary write object is `ClinicalAssertion`.

Examples:

- classification
- diagnosis
- differential
- treatment-option
- implant-consideration
- surgical-event interpretation
- complication/outcome classification
- rehab status
- recovery-trajectory assessment

An OrthoSkill MAY also propose:

- follow-up tasks;
- evidence requests;
- integrity warnings;
- outcome capture requests.

Such objects SHOULD be represented separately from confirmed clinical facts.

---

## 5. Confidence and uncertainty

A Skill MAY emit numeric confidence when meaningful.

It SHOULD also support qualitative uncertainty such as:

- insufficient evidence;
- ambiguous imaging;
- conflicting evidence;
- outside Skill scope;
- human review required.

Confidence MUST NOT be interpreted as human confirmation.

---

## 6. Human confirmation policy

The orchestration layer SHOULD define confirmation requirements by Skill and risk level.

Examples likely to require clinician confirmation include:

- diagnoses;
- classification used for treatment planning;
- treatment recommendations;
- implant selection;
- complication classification;
- causal outcome attribution.

A Skill MAY mark an assertion:

- `draft`
- `pending-confirmation`
- `confirmed`
- `rejected`
- `superseded`

A Skill itself MUST NOT mark its own output clinician-confirmed unless a valid human confirmation event
is provided.

---

## 7. Read semantics

A Skill SHOULD preferentially read:

1. Case Capsule manifest;
2. current state;
3. target-specific evidence;
4. relevant historical assertions;
5. provenance where needed.

A Skill MUST NOT assume that `current` means `authoritative source evidence`.

---

## 8. Write semantics

A Skill SHOULD append or create new structured objects.

A Skill SHOULD NOT:

- overwrite raw evidence;
- delete conflicting history;
- alter a human confirmation;
- retroactively change timestamps;
- silently convert a draft assertion to confirmed.

---

## 9. Supersession semantics

When new output replaces an existing interpretation, the new assertion SHOULD declare:

```json
{
  "supersedes": ["assertion-old-id"]
}
```

The persistence layer then changes the old assertion's lifecycle status through an auditable event.

---

## 10. Evidence citation

Every clinically material assertion SHOULD cite one or more `evidence_ids` unless the assertion is
explicitly derived from another assertion, in which case both the underlying assertion and ultimate
evidence lineage SHOULD remain recoverable.

External literature/guideline references SHOULD be distinguished from patient-specific evidence.

---

## 11. Example: AO/OTA Classification Skill

### Read

- target anatomy;
- radiographic evidence;
- image quality assessment;
- relevant CT;
- previous classification assertions.

### Reason

Apply the Skill's classification workflow.

### Assert

```json
{
  "type": "classification",
  "code_system": "AO/OTA",
  "value": "31-A2.3",
  "confidence": 0.94,
  "status": "pending-confirmation"
}
```

### Cite

Reference the radiograph and CT evidence IDs.

### Confirm

Request surgeon confirmation if used clinically.

### Write

Append the assertion and provenance event.

---

## 12. Example: Outcome Measurement Skill

### Read

- baseline functional state;
- intervention;
- follow-up date;
- PROM/ClinROM/Perf-ROM observations;
- expected trajectory where defined.

### Assert

Possible structured assertions:

- trajectory on track;
- delayed recovery;
- clinically important deterioration;
- missing outcome measurement.

### Write

Outcome observations remain observations. A derived trajectory interpretation is stored separately as
a ClinicalAssertion.

---

## 13. Example: DISH / Surgical Site Outcomes Skill

The Skill SHOULD distinguish:

- observed postoperative event;
- classification of the event;
- certainty;
- attribution to implant/procedure/disease.

Classification and causality are not the same object.

A causal statement SHOULD require stronger provenance and review than a descriptive event
classification.

---

## 14. Agent portability

The contract MUST remain usable by multiple runtimes.

No required field may assume only:

- Claude;
- OpenAI;
- Gemini;
- a specific local model;
- a specific MCP implementation.

Adapters MAY map a runtime's native tool-call structure into the Case Capsule contract.

---

## 15. Failure behavior

A Skill SHOULD fail safely when:

- required evidence is unavailable;
- evidence references cannot be resolved;
- schema validation fails;
- patient/case identity is inconsistent;
- source evidence integrity is uncertain;
- output is outside Skill scope.

The preferred failure output is a structured `needs-review` or `insufficient-evidence` result, not a
fabricated completion.

---

## 16. Integrity hooks

After a material Skill write, the runtime MAY trigger a Case Capsule Integrity Check.

High-value checks include:

- valid evidence references;
- duplicate active assertions;
- missing supersession;
- missing confirmation;
- invalid terminology/codes;
- contradictory active states.

---

## 17. Minimum Skill manifest extension

Future OrthoSkills SHOULD expose machine-readable metadata such as:

```yaml
case_capsule:
  reads:
    - evidence.imaging
    - assertions.image-quality
    - assertions.anatomy
  writes:
    - clinical-assertion.classification
  requires_confirmation: true
  may_supersede:
    - clinical-assertion.classification
```

This is illustrative and not yet normative.

---

## 18. Contract invariant

> **A Skill may reason over the Case Capsule, but it may not erase the distinction between evidence,
> interpretation and confirmation.**
