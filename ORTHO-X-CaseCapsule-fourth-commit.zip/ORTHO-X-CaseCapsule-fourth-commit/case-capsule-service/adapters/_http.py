from __future__ import annotations
import json
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError
class AdapterHTTPError(RuntimeError): pass
def request_json(url,*,headers=None,params=None,timeout=15.0):
    if params:
        q=urlencode({k:v for k,v in params.items() if v is not None},doseq=True)
        url += ('&' if '?' in url else '?')+q
    req=Request(url,headers=headers or {},method='GET')
    try:
        with urlopen(req,timeout=timeout) as r:
            b=r.read(); return None if not b else json.loads(b.decode('utf-8'))
    except HTTPError as e:
        body=e.read().decode('utf-8',errors='replace')
        raise AdapterHTTPError(f'HTTP {e.code} for {url}: {body[:500]}') from e
