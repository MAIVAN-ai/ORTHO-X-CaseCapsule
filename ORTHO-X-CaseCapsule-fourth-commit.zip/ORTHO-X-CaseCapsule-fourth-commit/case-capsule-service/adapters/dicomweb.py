from __future__ import annotations
from dataclasses import dataclass
from urllib.parse import quote
from adapters._http import request_json
STUDY_UID_TAG='0020000D'
@dataclass
class DICOMwebAdapter:
    base_url:str; bearer_token:str|None=None; timeout:float=15.0
    def _headers(self):
        h={'Accept':'application/dicom+json, application/json'}
        if self.bearer_token:h['Authorization']=f'Bearer {self.bearer_token}'
        return h
    def study_uri(self,uid): return f"{self.base_url.rstrip('/')}/studies/{quote(uid,safe='')}"
    def study_metadata_uri(self,uid): return self.study_uri(uid)+'/metadata'
    def qido_find_study(self,uid):
        r=request_json(self.base_url.rstrip('/')+'/studies',headers=self._headers(),params={'StudyInstanceUID':uid},timeout=self.timeout)
        if r is None:return []
        if not isinstance(r,list):raise ValueError('QIDO-RS response must be an array')
        return r
    def reference_for_study(self,uid,source_system=None,verify_qido=False):
        match=None
        if verify_qido:
            found=self.qido_find_study(uid)
            if not found:raise ValueError(f'DICOM Study not found: {uid}')
            match=found[0]
            vals=(match.get(STUDY_UID_TAG) or {}).get('Value') or []
            if vals and vals[0]!=uid:raise ValueError('QIDO-RS StudyInstanceUID mismatch')
        return {'kind':'dicom-study-reference','source_system':source_system or self.base_url,'source_identifier':uid,
        'source_uri':self.study_uri(uid),'metadata_uri':self.study_metadata_uri(uid),'dicom_study_instance_uid':uid,
        'qido_verified':bool(verify_qido)}
