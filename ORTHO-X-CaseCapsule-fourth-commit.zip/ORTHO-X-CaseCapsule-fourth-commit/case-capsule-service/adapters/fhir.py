from __future__ import annotations
from dataclasses import dataclass
from urllib.parse import urljoin
import hashlib,json
from adapters._http import request_json
@dataclass
class FHIRAdapter:
    base_url:str; bearer_token:str|None=None; timeout:float=15.0
    def _headers(self):
        h={'Accept':'application/fhir+json, application/json'}
        if self.bearer_token:h['Authorization']=f'Bearer {self.bearer_token}'
        return h
    def resource_url(self,resource_type,resource_id): return urljoin(self.base_url.rstrip('/')+'/',f'{resource_type}/{resource_id}')
    def read(self,resource_type,resource_id):
        o=request_json(self.resource_url(resource_type,resource_id),headers=self._headers(),timeout=self.timeout)
        if not isinstance(o,dict): raise ValueError('FHIR response is not an object')
        if o.get('resourceType') and o['resourceType']!=resource_type: raise ValueError('FHIR resourceType mismatch')
        return o
    def reference_from_resource(self,r,source_system=None):
        rt,rid=r.get('resourceType'),r.get('id')
        if not rt or not rid: raise ValueError('FHIR resource must contain resourceType and id')
        meta=r.get('meta') or {}; raw=json.dumps(r,sort_keys=True,separators=(',',':')).encode()
        return {'kind':f'fhir-{rt.lower()}','source_system':source_system or self.base_url,
        'source_identifier':f'{rt}/{rid}','source_uri':self.resource_url(rt,rid),'fhir_resource_type':rt,
        'fhir_resource_id':rid,'fhir_version_id':meta.get('versionId'),'fhir_last_updated':meta.get('lastUpdated'),
        'sha256':hashlib.sha256(raw).hexdigest()}
    def read_reference(self,resource_type,resource_id,source_system=None): return self.reference_from_resource(self.read(resource_type,resource_id),source_system)
