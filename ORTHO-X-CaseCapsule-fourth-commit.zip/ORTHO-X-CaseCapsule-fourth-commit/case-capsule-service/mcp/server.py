#!/usr/bin/env python3
from __future__ import annotations
import argparse,os,sys
from pathlib import Path
from typing import Any
HERE=Path(__file__).resolve(); SERVICE=HERE.parents[1]; sys.path.insert(0,str(SERVICE))
try: from mcp.server.fastmcp import FastMCP
except ImportError as e: raise SystemExit('Install: pip install "mcp[cli]>=2,<3"') from e
from service import CaseCapsuleService
mcp=FastMCP('ORTHO-X Case Capsule',json_response=True); service=CaseCapsuleService.from_env()
@mcp.tool(name='casecapsule.bootstrap')
def bootstrap(case_id:str,patient_ref:str|None=None)->dict:return service.bootstrap(case_id,patient_ref)
@mcp.tool(name='casecapsule.register_evidence')
def register_evidence(case_id:str,evidence_id:str,kind:str,source_system:str,source_identifier:str,occurred_at:str|None=None,sha256:str|None=None,summary:str|None=None)->dict:return service.register_evidence(case_id=case_id,evidence_id=evidence_id,kind=kind,source_system=source_system,source_identifier=source_identifier,occurred_at=occurred_at,sha256=sha256,summary=summary)
@mcp.tool(name='casecapsule.register_fhir_resource')
def register_fhir_resource(case_id:str,evidence_id:str,resource_type:str,resource_id:str,summary:str|None=None,source_system:str|None=None)->dict:return service.register_fhir_resource(case_id,evidence_id,resource_type,resource_id,summary,source_system)
@mcp.tool(name='casecapsule.register_dicom_study')
def register_dicom_study(case_id:str,evidence_id:str,study_instance_uid:str,summary:str|None=None,source_system:str|None=None,verify_qido:bool=False)->dict:return service.register_dicom_study(case_id,evidence_id,study_instance_uid,summary,source_system,verify_qido)
@mcp.tool(name='casecapsule.write_assertion')
def write_assertion(case_id:str,assertion_id:str,assertion_type:str,value:Any,evidence_refs:list[str],producer_id:str,human_readable:str|None=None,confidence:float|None=None,uncertainty:str|None=None,requires_confirmation:bool=True)->dict:return service.write_assertion(case_id,assertion_id,assertion_type,value,evidence_refs,producer_id,human_readable,confidence,uncertainty,requires_confirmation)
@mcp.tool(name='casecapsule.write_classification')
def write_classification(case_id:str,assertion_id:str,value:str,evidence_refs:list[str],code_system:str='AO/OTA',skill_name:str='ao-ota-classification',skill_version:str='0.1.0',confidence:float|None=None,uncertainty:str|None=None,human_readable:str|None=None,supersedes:list[str]|None=None,model_provider:str|None=None,model_id:str|None=None)->dict:return service.write_classification(case_id=case_id,assertion_id=assertion_id,value=value,evidence_refs=evidence_refs,code_system=code_system,skill_name=skill_name,skill_version=skill_version,confidence=confidence,uncertainty=uncertainty,human_readable=human_readable,supersedes=supersedes,model_provider=model_provider,model_id=model_id,runtime='mcp')
@mcp.tool(name='casecapsule.confirm')
def confirm(case_id:str,assertion_id:str,actor_id:str,role:str,reason:str|None=None)->dict:return service.confirm(case_id=case_id,assertion_id=assertion_id,actor_id=actor_id,role=role,reason=reason)
@mcp.tool(name='casecapsule.reject')
def reject(case_id:str,assertion_id:str,actor_id:str,role:str,reason:str|None=None)->dict:return service.reject(case_id=case_id,assertion_id=assertion_id,actor_id=actor_id,role=role,reason=reason)
@mcp.tool(name='casecapsule.record_surgery')
def record_surgery(case_id:str,assertion_id:str,evidence_refs:list[str],actor_id:str,role:str,procedure:str,performed_at:str|None=None,device_class:str|None=None,postoperative_plan:str|None=None,intraoperative_event_summary:str|None=None,human_readable:str|None=None)->dict:return service.record_surgery(case_id=case_id,assertion_id=assertion_id,evidence_refs=evidence_refs,actor_id=actor_id,role=role,procedure=procedure,performed_at=performed_at,device_class=device_class,postoperative_plan=postoperative_plan,intraoperative_event_summary=intraoperative_event_summary,human_readable=human_readable)
@mcp.tool(name='casecapsule.record_outcome')
def record_outcome(case_id:str,outcome_id:str,category:str,measure:str,value:Any,source_type:str,evidence_refs:list[str]|None=None,unit:str|None=None,observed_at:str|None=None,timepoint:str|None=None,instrument:str|None=None,baseline_ref:str|None=None,intervention_refs:list[str]|None=None,actor_id:str|None=None,role:str|None=None)->dict:return service.record_outcome(case_id=case_id,outcome_id=outcome_id,category=category,measure=measure,value=value,source_type=source_type,evidence_refs=evidence_refs,unit=unit,observed_at=observed_at,timepoint=timepoint,instrument=instrument,baseline_ref=baseline_ref,intervention_refs=intervention_refs,actor_id=actor_id,role=role)
@mcp.tool(name='casecapsule.current_state')
def current_state(case_id:str)->dict:return service.current_state(case_id)
@mcp.tool(name='casecapsule.integrity_check')
def integrity_check(case_id:str)->dict:return service.integrity_check(case_id)
def main():
 p=argparse.ArgumentParser();p.add_argument('--transport',choices=['stdio','streamable-http'],default='stdio');p.add_argument('--host',default='127.0.0.1');p.add_argument('--port',type=int,default=8765);a=p.parse_args()
 if a.transport=='stdio':mcp.run(transport='stdio')
 else:
  os.environ.setdefault('FASTMCP_HOST',a.host);os.environ.setdefault('FASTMCP_PORT',str(a.port));mcp.run(transport='streamable-http')
if __name__=='__main__':main()
