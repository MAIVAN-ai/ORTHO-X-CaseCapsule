import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from adapters.fhir import FHIRAdapter
from adapters.dicomweb import DICOMwebAdapter
class T(unittest.TestCase):
 def test_fhir(self):
  r=FHIRAdapter('https://x/fhir').reference_from_resource({'resourceType':'Condition','id':'c1','meta':{'versionId':'3'}});self.assertEqual(r['source_identifier'],'Condition/c1');self.assertEqual(len(r['sha256']),64)
 def test_dicom(self):
  r=DICOMwebAdapter('https://x/dicom-web').reference_for_study('1.2.3');self.assertEqual(r['dicom_study_instance_uid'],'1.2.3');self.assertFalse(r['qido_verified'])
if __name__=='__main__':unittest.main()
