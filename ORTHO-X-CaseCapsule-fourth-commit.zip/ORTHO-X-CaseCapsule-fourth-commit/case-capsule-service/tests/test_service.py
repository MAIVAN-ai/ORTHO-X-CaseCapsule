import os,sys,tempfile,shutil,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from backend import LocalCapsuleBackend
from service import CaseCapsuleService
class T(unittest.TestCase):
 def setUp(self):self.tmp=Path(tempfile.mkdtemp());self.s=CaseCapsuleService(LocalCapsuleBackend(self.tmp/'caps',Path(os.environ['TEST_CASECAPSULE_RUNTIME'])))
 def tearDown(self):shutil.rmtree(self.tmp,ignore_errors=True)
 def test_flow(self):
  self.s.bootstrap('cc-test');self.s.register_evidence(case_id='cc-test',evidence_id='ev-x',kind='dicom-study-reference',source_system='pacs',source_identifier='1.2.3');a=self.s.write_classification(case_id='cc-test',assertion_id='as-c',value='31-A2.3',evidence_refs=['ev-x'],confidence=.9);self.assertEqual(a['status'],'pending-confirmation');self.s.confirm(case_id='cc-test',assertion_id='as-c',actor_id='s1',role='surgeon');self.assertTrue(self.s.integrity_check('cc-test')['ok'])
if __name__=='__main__':unittest.main()
