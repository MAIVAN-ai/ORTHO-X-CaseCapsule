# ORTHO-X Case Capsule Service

Interoperability/service layer for the ORTHO-X Case Capsule runtime.

This commit exposes the Case Capsule contract through **FHIR**, **DICOMweb**, and **MCP** while retaining the commit-3 file runtime as a replaceable backend adapter.

> Research/development reference only. Not a medical device. The service does not perform autonomous diagnosis or treatment selection.

## Architecture

```text
Agent / OrthoFlow
      │
      ▼
MCP tool surface
      │
 ┌────┼───────────────┐
 │    │               │
 ▼    ▼               ▼
Case  FHIR adapter   DICOMweb adapter
Capsule│               │
backend▼               ▼
     EHR/FHIR        PACS/VNA
```

FHIR and DICOM adapters are **reference-first**: register stable source identifiers, URLs, versions and hashes where feasible instead of copying unnecessary hospital data.

## MCP tools

- `casecapsule.bootstrap`
- `casecapsule.register_evidence`
- `casecapsule.register_fhir_resource`
- `casecapsule.register_dicom_study`
- `casecapsule.write_assertion`
- `casecapsule.write_classification`
- `casecapsule.confirm`
- `casecapsule.reject`
- `casecapsule.record_surgery`
- `casecapsule.record_outcome`
- `casecapsule.current_state`
- `casecapsule.integrity_check`

## Install / run

```bash
pip install "mcp[cli]>=2,<3"
python3 case-capsule-service/mcp/server.py --transport stdio
```

For Streamable HTTP:

```bash
python3 case-capsule-service/mcp/server.py --transport streamable-http --host 127.0.0.1 --port 8765
```

Set:

```bash
export CASECAPSULE_ROOT=./var/case-capsules
export CASECAPSULE_RUNTIME=./case-capsule-skill/scripts/capsule_runtime.py
export FHIR_BASE_URL=https://hospital.example/fhir
export DICOMWEB_BASE_URL=https://pacs.example/dicom-web
```

Never commit credentials. Remote clinical deployment requires authenticated identity, authorization, TLS, audit, case scoping, network controls and deployment-specific security review.
