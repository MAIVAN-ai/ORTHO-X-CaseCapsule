from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json,os,subprocess,sys
class BackendError(RuntimeError):pass
@dataclass
class LocalCapsuleBackend:
    root:Path; runtime:Path
    @classmethod
    def from_env(cls):return cls(Path(os.getenv('CASECAPSULE_ROOT','./var/case-capsules')).resolve(),Path(os.getenv('CASECAPSULE_RUNTIME','case-capsule-skill/scripts/capsule_runtime.py')).resolve())
    def capsule_path(self,c):
        if '/' in c or '\\' in c or c in ('.','..'):raise BackendError('Invalid case_id')
        return self.root/c
    def _run(self,*args):
        if not self.runtime.exists():raise BackendError(f'Runtime not found: {self.runtime}')
        p=subprocess.run([sys.executable,str(self.runtime),*map(str,args)],capture_output=True,text=True)
        if p.returncode:raise BackendError((p.stderr or p.stdout).strip())
        try:return json.loads(p.stdout)
        except:return {'ok':True,'output':p.stdout.strip()}
    def bootstrap(self,case_id,patient_ref=None):
        self.root.mkdir(parents=True,exist_ok=True); a=['bootstrap',self.capsule_path(case_id),'--case-id',case_id]
        if patient_ref:a+=['--patient-ref',patient_ref]
        return self._run(*a)
    def register_evidence(self,case_id,*,evidence_id,kind,source_system,source_identifier,occurred_at=None,sha256=None,summary=None):
        a=['register-evidence',self.capsule_path(case_id),'--evidence-id',evidence_id,'--kind',kind,'--source-system',source_system,'--source-identifier',source_identifier]
        for flag,val in [('--occurred-at',occurred_at),('--sha256',sha256),('--summary',summary)]:
            if val:a += [flag,val]
        return self._run(*a)
    def write_classification(self,case_id,*,assertion_id,value,evidence_refs,code_system='AO/OTA',skill_name='ao-ota-classification',skill_version='0.1.0',confidence=None,uncertainty=None,human_readable=None,supersedes=None,model_provider=None,model_id=None,runtime='mcp'):
        a=['run-classification',self.capsule_path(case_id),'--assertion-id',assertion_id,'--value',value,'--code-system',code_system,'--skill-name',skill_name,'--skill-version',skill_version]
        for r in evidence_refs:a += ['--evidence-ref',r]
        for r in supersedes or []:a += ['--supersedes',r]
        for flag,val in [('--confidence',confidence),('--uncertainty',uncertainty),('--human-readable',human_readable),('--model-provider',model_provider),('--model-id',model_id),('--runtime',runtime)]:
            if val is not None:a += [flag,str(val)]
        return self._run(*a)
    def _status(self,cmd,case_id,assertion_id,actor_id,role,reason=None):
        a=[cmd,self.capsule_path(case_id),'--assertion-id',assertion_id,'--actor-id',actor_id,'--role',role]
        if reason:a += ['--reason',reason]
        return self._run(*a)
    def confirm(self,**k):return self._status('confirm-assertion',**k)
    def reject(self,**k):return self._status('reject-assertion',**k)
    def record_surgery(self,case_id,*,assertion_id,evidence_refs,actor_id,role,procedure,performed_at=None,device_class=None,postoperative_plan=None,intraoperative_event_summary=None,human_readable=None):
        a=['record-surgery',self.capsule_path(case_id),'--assertion-id',assertion_id,'--actor-id',actor_id,'--role',role,'--procedure',procedure]
        for r in evidence_refs:a += ['--evidence-ref',r]
        for flag,val in [('--performed-at',performed_at),('--device-class',device_class),('--postoperative-plan',postoperative_plan),('--intraoperative-event-summary',intraoperative_event_summary),('--human-readable',human_readable)]:
            if val:a += [flag,val]
        return self._run(*a)
    def record_outcome(self,case_id,*,outcome_id,category,measure,value,source_type,evidence_refs=None,unit=None,observed_at=None,timepoint=None,instrument=None,baseline_ref=None,intervention_refs=None,actor_id=None,role=None):
        val=json.dumps(value,separators=(',',':')) if not isinstance(value,str) else value
        a=['record-outcome',self.capsule_path(case_id),'--outcome-id',outcome_id,'--category',category,'--measure',measure,'--value',val,'--source-type',source_type]
        for r in evidence_refs or []:a += ['--evidence-ref',r]
        for r in intervention_refs or []:a += ['--intervention-ref',r]
        for flag,v in [('--unit',unit),('--observed-at',observed_at),('--timepoint',timepoint),('--instrument',instrument),('--baseline-ref',baseline_ref),('--actor-id',actor_id),('--role',role)]:
            if v:a += [flag,v]
        return self._run(*a)
    def current_state(self,case_id):return self._run('current-state',self.capsule_path(case_id))
    def integrity_check(self,case_id):return self._run('integrity-check',self.capsule_path(case_id))
