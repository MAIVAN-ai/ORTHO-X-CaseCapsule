from __future__ import annotations
import json, os
from datetime import datetime, timezone
from backend import LocalCapsuleBackend, BackendError
from adapters.fhir import FHIRAdapter
from adapters.dicomweb import DICOMwebAdapter

class CaseCapsuleService:
    def __init__(self, backend):
        self.backend = backend

    @classmethod
    def from_env(cls):
        return cls(LocalCapsuleBackend.from_env())

    def bootstrap(self, case_id, patient_ref=None):
        return self.backend.bootstrap(case_id, patient_ref)

    def register_evidence(self, **kwargs):
        return self.backend.register_evidence(**kwargs)

    def register_fhir_resource(self, case_id, evidence_id, resource_type, resource_id,
                               summary=None, source_system=None):
        base = os.getenv('FHIR_BASE_URL')
        token = os.getenv('FHIR_BEARER_TOKEN')
        if not base:
            raise BackendError('FHIR_BASE_URL is not configured')
        ref = FHIRAdapter(base, token).read_reference(resource_type, resource_id, source_system)
        return self.backend.register_evidence(
            case_id,
            evidence_id=evidence_id,
            kind=ref['kind'],
            source_system=ref['source_system'],
            source_identifier=ref['source_identifier'],
            sha256=ref['sha256'],
            summary=summary or f'FHIR {resource_type}/{resource_id}',
        )

    def register_dicom_study(self, case_id, evidence_id, study_instance_uid,
                             summary=None, source_system=None, verify_qido=False):
        base = os.getenv('DICOMWEB_BASE_URL')
        token = os.getenv('DICOMWEB_BEARER_TOKEN')
        if not base:
            raise BackendError('DICOMWEB_BASE_URL is not configured')
        ref = DICOMwebAdapter(base, token).reference_for_study(
            study_instance_uid, source_system, verify_qido
        )
        return self.backend.register_evidence(
            case_id,
            evidence_id=evidence_id,
            kind=ref['kind'],
            source_system=ref['source_system'],
            source_identifier=ref['source_identifier'],
            summary=summary or f'DICOM Study {study_instance_uid}',
        )

    def write_classification(self, **kwargs):
        return self.backend.write_classification(**kwargs)

    def write_assertion(self, case_id, assertion_id, assertion_type, value,
                        evidence_refs, producer_id, human_readable=None,
                        confidence=None, uncertainty=None, requires_confirmation=True):
        root = self.backend.capsule_path(case_id)
        manifest_path = root / 'manifest.json'
        if not manifest_path.exists():
            raise BackendError(f'Unknown Case Capsule: {case_id}')

        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        missing = [r for r in evidence_refs if r not in set(manifest.get('evidence_ids', []))]
        if missing:
            raise BackendError(f'Unknown evidence refs: {missing}')
        if assertion_id in manifest.get('assertion_ids', []):
            raise BackendError(f'Assertion already exists: {assertion_id}')

        now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
        obj = {
            'schema_version': '0.1.0',
            'assertion_id': assertion_id,
            'case_capsule_id': case_id,
            'type': assertion_type,
            'code_system': None,
            'code': None,
            'value': value,
            'human_readable': human_readable,
            'status': 'pending-confirmation' if requires_confirmation else 'draft',
            'confidence': confidence,
            'uncertainty': uncertainty,
            'evidence_refs': evidence_refs,
            'derived_from_assertion_refs': [],
            'producer': {
                'actor_type': 'skill',
                'actor_id': producer_id,
                'skill_name': producer_id,
                'skill_version': None,
                'model_provider': None,
                'model_id': None,
                'runtime': 'mcp',
            },
            'created_at': now,
            'confirmed_at': None,
            'confirmed_by': None,
            'supersedes': [],
            'superseded_by': None,
            'provenance_event_refs': [],
            'extensions': {'requires_confirmation': requires_confirmation},
        }

        skills_dir = root / 'skills'
        skills_dir.mkdir(exist_ok=True)
        safe = ''.join(c for c in assertion_id if c.isalnum() or c in '-_.')
        (skills_dir / f'{assertion_type}.{safe}.json').write_text(
            json.dumps(obj, indent=2) + '\n', encoding='utf-8'
        )

        manifest.setdefault('assertion_ids', []).append(assertion_id)
        manifest['current_state_version'] = manifest.get('current_state_version', 0) + 1

        events = root / 'provenance' / 'events.jsonl'
        next_num = 1
        if events.exists():
            for line in events.read_text(encoding='utf-8').splitlines():
                try:
                    event = json.loads(line)
                    eid = event.get('event_id', '')
                    if eid.startswith('pe-') and eid[3:].isdigit():
                        next_num = max(next_num, int(eid[3:]) + 1)
                except Exception:
                    pass

        event = {
            'schema_version': '0.1.0',
            'event_id': f'pe-{next_num:03d}',
            'case_capsule_id': case_id,
            'event_type': 'assertion.created',
            'occurred_at': now,
            'recorded_at': now,
            'actor': {'actor_type': 'skill', 'actor_id': producer_id, 'role': None},
            'target_refs': [],
            'input_refs': evidence_refs,
            'output_refs': [assertion_id],
            'reason': None,
            'execution': None,
            'previous_event_hash': None,
            'event_hash': None,
            'extensions': {'runtime': 'mcp-service'},
        }
        events.parent.mkdir(exist_ok=True)
        with events.open('a', encoding='utf-8') as f:
            f.write(json.dumps(event, separators=(',', ':')) + '\n')

        manifest.setdefault('provenance_event_ids', []).append(event['event_id'])
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
        self.backend.current_state(case_id)
        return obj

    def confirm(self, **kwargs):
        return self.backend.confirm(**kwargs)

    def reject(self, **kwargs):
        return self.backend.reject(**kwargs)

    def record_surgery(self, **kwargs):
        return self.backend.record_surgery(**kwargs)

    def record_outcome(self, **kwargs):
        return self.backend.record_outcome(**kwargs)

    def current_state(self, case_id):
        return self.backend.current_state(case_id)

    def integrity_check(self, case_id):
        return self.backend.integrity_check(case_id)
