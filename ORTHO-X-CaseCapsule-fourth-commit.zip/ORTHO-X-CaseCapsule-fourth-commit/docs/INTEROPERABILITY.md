# FHIR / DICOMweb / MCP Interoperability

## FHIR
FHIR resources are registered as authoritative external evidence references. The adapter records `ResourceType/id`, source URL, `meta.versionId`, `meta.lastUpdated`, and a SHA-256 digest of the retrieved JSON. Candidate mappings include ServiceRequest/DocumentReference for referral, Condition for diagnosis, ImagingStudy/DiagnosticReport for imaging, Procedure for surgery, Observation for measurements, QuestionnaireResponse for PROMs, and Provenance for provenance. Exact profiles remain deployment-specific.

## DICOMweb
The adapter treats Study Instance UID as the primary imaging reference. It can verify/search a Study through **QIDO-RS** and constructs Study/metadata URLs suitable for authorized **WADO-RS** retrieval. Pixel data is not downloaded automatically.

## MCP
MCP is the agent-facing interoperability layer. The model host can change while the Case Capsule persistence contract stays stable.

## Production boundary
MCP interoperability is not clinical authorization. Production requires authenticated identity, patient/case authorization, least privilege, audit, TLS, network controls, data-residency policy, and credential management.
