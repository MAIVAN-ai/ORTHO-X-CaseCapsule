# Service Security Notes

The reference server must not be exposed directly to a clinical network without a deployment security layer.

Required production controls include authentication, per-case authorization, TLS, secret management, audit, private-network exposure, rate/resource limits, input/path isolation, retention policies, and threat modeling.

## Human confirmation
`casecapsule.confirm` only persists a human confirmation event. A production MCP host must bind the claimed `actor_id` to an authenticated human identity; a model must not be able to impersonate a clinician by supplying an arbitrary identifier.
