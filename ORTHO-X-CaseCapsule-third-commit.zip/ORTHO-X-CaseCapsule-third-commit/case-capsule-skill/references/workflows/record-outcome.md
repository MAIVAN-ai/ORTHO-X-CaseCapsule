# Workflow: Record Outcome

Persist patient-reported, clinician-reported, performance, functional, complication or
other longitudinal outcome observations.

An outcome observation is not itself a causal claim.

Recommended fields:
- category
- measure
- value
- unit
- observed_at
- timepoint
- source type
- evidence refs
- instrument
- baseline ref
- intervention refs

ICHOM-aligned implementations should map to official licensed/current data dictionaries
where applicable rather than guessing instrument semantics.
