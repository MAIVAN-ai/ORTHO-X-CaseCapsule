# Workflow: Bootstrap Case Capsule

## Goal
Create a new empty Case Capsule without patient-identifying content.

## Required inputs
- target directory
- Case Capsule ID
- optional pseudonymous patient reference

## Procedure
1. Refuse to overwrite an existing non-empty target.
2. Create the standard directories.
3. Create `manifest.json`.
4. Create an empty `raw/evidence-manifest.json`.
5. Create `outcomes/outcome-observations.json` as `[]`.
6. Create empty `provenance/events.jsonl`.
7. Create derived `clinical/current-state.json`.
8. Append `capsule.created` provenance.
9. Run integrity check.

## Runtime
`capsule_runtime.py bootstrap <path> --case-id <id> [--patient-ref <ref>]`
