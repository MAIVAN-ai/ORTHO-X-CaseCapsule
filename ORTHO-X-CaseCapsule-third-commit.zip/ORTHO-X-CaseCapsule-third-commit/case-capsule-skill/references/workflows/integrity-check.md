# Workflow: Case Capsule Integrity Check

The check should detect at minimum:
- invalid or missing manifest
- duplicate IDs
- assertion → missing evidence references
- outcome → missing evidence references
- supersedes → missing assertion
- multiple active confirmed classifications for the same code system
- `confirmed` assertion without human confirmer
- superseded assertion not marked `superseded`
- manifest inventory drift
- malformed JSON/JSONL
- provenance references to unknown targets/inputs/outputs

Severity:
- ERROR: structural/provenance inconsistency that should block trusted use
- WARNING: plausible but incomplete state requiring review
- INFO: non-blocking maintenance note

The checker does not resolve clinical disagreement automatically.
