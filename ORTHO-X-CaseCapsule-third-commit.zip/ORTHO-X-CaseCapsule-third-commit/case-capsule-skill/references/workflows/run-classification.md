# Workflow: Persist Classification Skill Output

## Goal
Persist the output of a classification OrthoSkill.

## Separation of responsibilities
The Case Capsule runtime DOES NOT perform AO/OTA reasoning. The calling OrthoSkill does.

## Procedure
1. Confirm all evidence refs exist.
2. Receive classification code/value, Skill identity/version and confidence.
3. Create a new `classification` ClinicalAssertion.
4. Default status to `pending-confirmation`.
5. If it supersedes an earlier assertion, record the relationship without deleting history.
6. Append `skill.executed` and `assertion.created` provenance.
7. Refresh current state.
8. If clinically used, request explicit human confirmation.

## Runtime
`capsule_runtime.py run-classification <capsule> --assertion-id ... --value ... --code-system AO/OTA --evidence-ref ... --skill-name ...`
