# Workflow: Register Evidence

Register imaging, operative notes, lab results, rehab assessments, PROM source records,
or other authoritative evidence references.

Required fields:
- evidence ID
- kind
- source system
- source identifier
- occurred-at
- optional SHA-256
- optional summary

Evidence IDs are immutable once registered. A corrected source-system reference should
be represented through a new evidence object plus provenance rather than silent rewrite.
