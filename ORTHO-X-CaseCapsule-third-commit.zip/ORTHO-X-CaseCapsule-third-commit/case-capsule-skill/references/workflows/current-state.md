# Workflow: Current State

Generate a convenience view of the best currently accepted Case Capsule state.

Current state is DERIVED.
It must be reproducible from assertions/outcomes/provenance and must never replace history.

Selection principles:
1. confirmed non-superseded assertions outrank pending assertions;
2. superseded/rejected/entered-in-error assertions are historical;
3. outcome observations remain time-series data;
4. disagreement is surfaced, not silently collapsed.
