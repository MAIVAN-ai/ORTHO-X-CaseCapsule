# Workflow: Record Postoperative / Surgical-site Event

Use for wound events, complications, adverse events and other postoperative observations.

For DISH-oriented surgical-site recording, keep the observed domains separate:
- dehiscence
- infection
- seroma
- haematoma

Do not conflate descriptive event classification with causal attribution to implant,
procedure, disease or clinician.
