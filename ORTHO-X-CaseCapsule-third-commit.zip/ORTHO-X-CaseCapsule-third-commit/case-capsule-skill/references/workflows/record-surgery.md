# Workflow: Record Surgery

Register the authoritative operative-note reference first, then persist a structured
`surgical-event` assertion.

The operative event may contain:
- procedure label
- procedure coding where available
- intervention time
- implant/device-class references
- intraoperative events
- postoperative plan

Do not infer "no complication" merely from absent data. Only record absence when the
authoritative source explicitly supports it.
