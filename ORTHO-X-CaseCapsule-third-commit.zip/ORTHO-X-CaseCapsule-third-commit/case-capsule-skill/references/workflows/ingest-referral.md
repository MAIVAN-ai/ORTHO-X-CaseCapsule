# Workflow: Ingest Referral

## Goal
Register a referral/history source as immutable evidence.

## Important
The runtime stores a structured evidence record or pointer. Production deployments
should reference authoritative EHR/FHIR content rather than duplicate unnecessary PHI.

## Procedure
1. Resolve Case Capsule identity.
2. Reject duplicate evidence IDs.
3. Register evidence with kind `referral`.
4. Append `evidence.registered`.
5. Optionally persist a separate Case Intake assertion produced by OrthoSkills.
6. Refresh current state and run integrity check.

## Runtime
`capsule_runtime.py ingest-referral <capsule> --evidence-id ... --source-system ... --source-identifier ... --summary ...`
