# Workflow: Confirm / Reject Assertion

## Human confirmation
Confirmation requires:
- assertion ID
- human actor ID
- actor role
- timestamp

`confirm-assertion` changes lifecycle state to `confirmed` and appends
`assertion.confirmed`.

`reject-assertion` changes lifecycle state to `rejected` and appends
`assertion.rejected`.

No assertion is deleted.

A later corrected interpretation should normally be a NEW assertion referencing
the earlier assertion through `supersedes`.
