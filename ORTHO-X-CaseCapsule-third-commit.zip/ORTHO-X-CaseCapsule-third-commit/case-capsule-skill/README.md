# Executable Reference Runtime

This file-based runtime turns the Case Capsule specification into an executable development surface.

## Commands

```bash
python3 case-capsule-skill/scripts/capsule_runtime.py bootstrap ...
python3 case-capsule-skill/scripts/capsule_runtime.py ingest-referral ...
python3 case-capsule-skill/scripts/capsule_runtime.py register-evidence ...
python3 case-capsule-skill/scripts/capsule_runtime.py run-classification ...
python3 case-capsule-skill/scripts/capsule_runtime.py confirm-assertion ...
python3 case-capsule-skill/scripts/capsule_runtime.py reject-assertion ...
python3 case-capsule-skill/scripts/capsule_runtime.py record-surgery ...
python3 case-capsule-skill/scripts/capsule_runtime.py record-event ...
python3 case-capsule-skill/scripts/capsule_runtime.py record-outcome ...
python3 case-capsule-skill/scripts/capsule_runtime.py current-state ...
python3 case-capsule-skill/scripts/capsule_runtime.py integrity-check ...
```

## OrthoFlow pattern

```text
OrthoFlow
   │
   ├── invokes Case Capsule Skill → register evidence
   │
   ├── invokes OrthoSkill         → reason
   │
   ├── receives assertion         → validate
   │
   ├── invokes Case Capsule Skill → persist assertion
   │
   ├── requests human review      → confirm/reject
   │
   └── later records outcomes     → close loop
```

## Important boundary

`run-classification` persists a classification result supplied by an OrthoSkill.
It is intentionally not an AO/OTA classifier itself.
