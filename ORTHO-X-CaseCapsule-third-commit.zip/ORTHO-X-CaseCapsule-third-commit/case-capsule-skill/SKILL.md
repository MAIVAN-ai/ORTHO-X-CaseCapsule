---
name: ortho-x-case-capsule
description: >
  Bootstrap and operate an ORTHO-X Case Capsule: a persistent, provenance-aware
  longitudinal clinical memory layer with immutable evidence references,
  structured clinical assertions, explicit human confirmation, supersession,
  surgical events, rehabilitation, outcomes, and integrity checks. Use when
  the user asks to create a Case Capsule; ingest a referral; register imaging
  or other evidence; run or record a clinical classification; confirm, reject,
  correct, or supersede an assertion; record surgery; record postoperative
  events; record rehabilitation or patient-centred outcomes; inspect current
  state; or run a Case Capsule integrity check.
version: 0.1.0
---

# ORTHO-X Case Capsule Bootstrap + Update Skill

Operate longitudinal ORTHO-X Case Capsules without collapsing the distinction
between **source evidence**, **derived interpretation**, and **human confirmation**.

This Skill is a persistence/orchestration contract. It does not itself diagnose
or select treatment. Domain reasoning is delegated to the relevant OrthoSkill.

## Core invariant

> Source evidence remains authoritative; Skills create structured assertions;
> clinically material assertions remain traceable; human review is explicit;
> supersession preserves history; outcomes close the longitudinal loop.

## Operating model

- Treat `raw/` evidence references as immutable after registration.
- Never silently replace a prior clinical assertion.
- Append a provenance event for every clinically material mutation.
- Use `manifest.json` as the Capsule object inventory.
- Use `clinical/current-state.json` as a derived convenience view, never as the
  sole historical record.
- Use `provenance/events.jsonl` as append-only operation history.
- Store Skill outputs as structured JSON assertion objects.
- Store outcome observations separately from causal interpretations.
- Require human confirmation where the calling OrthoSkill or orchestration
  policy marks an assertion as confirmation-required.
- Never represent model confidence as human confirmation.
- Never store private chain-of-thought as provenance.

## Intent router

| User / agent intent | Operation | Reference |
| --- | --- | --- |
| Create a new Case Capsule | `bootstrap` | `references/workflows/bootstrap.md` |
| Add referral/history/exam source | `ingest-referral` | `references/workflows/ingest-referral.md` |
| Add imaging or other source evidence | `register-evidence` | `references/workflows/register-evidence.md` |
| Persist an OrthoSkill classification result | `run-classification` | `references/workflows/run-classification.md` |
| Confirm/reject an assertion | `confirm-assertion` / `reject-assertion` | `references/workflows/confirm-assertion.md` |
| Record an operation | `record-surgery` | `references/workflows/record-surgery.md` |
| Record surgical-site / postoperative event | `record-event` | `references/workflows/record-event.md` |
| Record PROM/ClinROM/Perf-ROM or other outcome | `record-outcome` | `references/workflows/record-outcome.md` |
| Check consistency and provenance | `integrity-check` | `references/workflows/integrity-check.md` |
| Show accepted case state | `current-state` | `references/workflows/current-state.md` |

## Runtime

The reference runtime is:

```bash
python3 case-capsule-skill/scripts/capsule_runtime.py --help
```

Example:

```bash
python3 case-capsule-skill/scripts/capsule_runtime.py \
  integrity-check examples/synthetic-proximal-femur-001
```

The Python runtime is deliberately dependency-light and file-based. It is a
reference adapter for development/testing, not the required production storage
engine.

## Domain Skill hand-off

When an operation requires clinical reasoning:

1. read the relevant Case Capsule evidence;
2. invoke the appropriate OrthoSkill;
3. receive a structured proposed assertion;
4. validate it;
5. persist it with provenance;
6. request/record human confirmation when required.

The Case Capsule Skill MUST NOT invent a classification, diagnosis, treatment,
or causal attribution merely because the persistence command was requested.

## Hard rules

- Never modify an already registered raw evidence object in place.
- Never delete a superseded assertion from history.
- Never mark an assertion `confirmed` without an explicit human actor.
- Never treat an LLM answer as source evidence.
- Never infer causal attribution from chronology alone.
- Never write identifiable clinical data to a public repository fixture.
- On schema or identity mismatch, fail closed and report the inconsistency.
- Integrity check may report and suggest fixes, but must not autonomously resolve
  clinically meaningful disagreement.

## Minimal generated Capsule

```text
<case-capsule>/
├── manifest.json
├── raw/
│   └── evidence-manifest.json
├── clinical/
│   └── current-state.json
├── skills/
├── outcomes/
│   └── outcome-observations.json
├── provenance/
│   └── events.jsonl
└── capsule/
    └── index.md
```

## Safety

Research/development reference only. Not a medical device. Not for autonomous
clinical decision-making. Clinical use requires appropriately qualified human
review and deployment-specific governance.
