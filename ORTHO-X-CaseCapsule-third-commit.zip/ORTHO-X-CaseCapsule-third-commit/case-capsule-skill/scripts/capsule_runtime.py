#!/usr/bin/env python3
"""
ORTHO-X Case Capsule reference runtime v0.1.

File-based development adapter for bootstrapping and updating Case Capsules.
No external dependencies. Research/development only; not a medical device.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

VERSION = "0.1.0"

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)

def append_jsonl(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")

def capsule_paths(root: Path) -> dict[str, Path]:
    return {
        "manifest": root/"manifest.json",
        "evidence": root/"raw"/"evidence-manifest.json",
        "outcomes": root/"outcomes"/"outcome-observations.json",
        "events": root/"provenance"/"events.jsonl",
        "current": root/"clinical"/"current-state.json",
        "skills": root/"skills",
        "index": root/"capsule"/"index.md",
    }

def must_capsule(root: Path) -> tuple[dict, dict[str, Path]]:
    p = capsule_paths(root)
    if not p["manifest"].exists():
        raise SystemExit(f"Not a Case Capsule: missing {p['manifest']}")
    return load_json(p["manifest"]), p

def load_evidence(p: dict[str, Path]) -> dict:
    if not p["evidence"].exists():
        return {"schema_version": VERSION, "case_capsule_id": None, "evidence": []}
    return load_json(p["evidence"])

def load_outcomes(p: dict[str, Path]) -> list:
    if not p["outcomes"].exists():
        return []
    return load_json(p["outcomes"])

def load_assertions(p: dict[str, Path]) -> list[tuple[Path, dict]]:
    out = []
    if not p["skills"].exists():
        return out
    for fp in sorted(p["skills"].glob("*.json")):
        try:
            obj = load_json(fp)
            if isinstance(obj, dict) and "assertion_id" in obj:
                out.append((fp, obj))
        except Exception:
            continue
    return out

def find_assertion(p: dict[str, Path], assertion_id: str) -> tuple[Path, dict]:
    for fp, a in load_assertions(p):
        if a.get("assertion_id") == assertion_id:
            return fp, a
    raise SystemExit(f"Unknown assertion_id: {assertion_id}")

def next_event_id(p: dict[str, Path]) -> str:
    n = 0
    if p["events"].exists():
        for line in p["events"].read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                e = json.loads(line)
                eid = e.get("event_id", "")
                if eid.startswith("pe-") and eid[3:].isdigit():
                    n = max(n, int(eid[3:]))
            except Exception:
                pass
    return f"pe-{n+1:03d}"

def event(manifest: dict, p: dict[str, Path], event_type: str, actor_type: str,
          actor_id: str, *, targets=None, inputs=None, outputs=None, reason=None,
          role=None, execution=None) -> dict:
    e = {
        "schema_version": VERSION,
        "event_id": next_event_id(p),
        "case_capsule_id": manifest["case_capsule_id"],
        "event_type": event_type,
        "occurred_at": now_iso(),
        "recorded_at": now_iso(),
        "actor": {"actor_type": actor_type, "actor_id": actor_id, "role": role},
        "target_refs": targets or [],
        "input_refs": inputs or [],
        "output_refs": outputs or [],
        "reason": reason,
        "execution": execution,
        "previous_event_hash": None,
        "event_hash": None,
        "extensions": {"runtime": "capsule_runtime.py", "runtime_version": VERSION},
    }
    append_jsonl(p["events"], e)
    manifest.setdefault("provenance_event_ids", []).append(e["event_id"])
    return e

def write_manifest(manifest: dict, p: dict[str, Path]) -> None:
    manifest["updated_at"] = now_iso()
    save_json(p["manifest"], manifest)

def refresh_current_state(root: Path) -> dict:
    manifest, p = must_capsule(root)
    assertions = [a for _, a in load_assertions(p)]
    accepted = []
    pending = []
    historical = []
    for a in assertions:
        s = a.get("status")
        if s == "confirmed" and not a.get("superseded_by"):
            accepted.append(a)
        elif s in ("draft", "pending-confirmation"):
            pending.append(a)
        else:
            historical.append(a)

    outcomes = load_outcomes(p)
    state = {
        "schema_version": VERSION,
        "case_capsule_id": manifest["case_capsule_id"],
        "generated_at": now_iso(),
        "derived": True,
        "accepted_assertions": [
            {
                "assertion_id": a["assertion_id"],
                "type": a.get("type"),
                "code_system": a.get("code_system"),
                "code": a.get("code"),
                "value": a.get("value"),
                "human_readable": a.get("human_readable"),
            } for a in accepted
        ],
        "pending_assertions": [
            {
                "assertion_id": a["assertion_id"],
                "type": a.get("type"),
                "value": a.get("value"),
                "status": a.get("status"),
            } for a in pending
        ],
        "historical_assertion_ids": [a["assertion_id"] for a in historical],
        "latest_outcomes": latest_outcomes(outcomes),
    }
    save_json(p["current"], state)
    return state

def latest_outcomes(outcomes: list[dict]) -> list[dict]:
    by_measure = {}
    for o in outcomes:
        key = o.get("measure")
        ts = o.get("observed_at", "")
        if key not in by_measure or ts > by_measure[key].get("observed_at", ""):
            by_measure[key] = o
    return list(by_measure.values())

def cmd_bootstrap(args):
    root = Path(args.path)
    if root.exists() and any(root.iterdir()):
        raise SystemExit("Refusing to overwrite non-empty target directory.")
    for d in ["raw", "clinical", "skills", "outcomes", "provenance", "capsule"]:
        (root/d).mkdir(parents=True, exist_ok=True)
    p = capsule_paths(root)
    manifest = {
        "schema_version": VERSION,
        "case_capsule_id": args.case_id,
        "patient_ref": args.patient_ref,
        "encounter_refs": [],
        "status": "active",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "authoritative_system_refs": [],
        "evidence_ids": [],
        "assertion_ids": [],
        "outcome_observation_ids": [],
        "provenance_event_ids": [],
        "current_state_version": 0,
        "tags": ["case-capsule"],
        "extensions": {},
    }
    save_json(p["manifest"], manifest)
    save_json(p["evidence"], {"schema_version": VERSION, "case_capsule_id": args.case_id, "evidence": []})
    save_json(p["outcomes"], [])
    p["events"].touch()
    event(manifest, p, "capsule.created", "system-service", "case-capsule-runtime", outputs=[args.case_id])
    write_manifest(manifest, p)
    refresh_current_state(root)
    print(json.dumps({"ok": True, "case_capsule_id": args.case_id, "path": str(root)}, indent=2))

def register_evidence(root: Path, args, kind_override=None):
    manifest, p = must_capsule(root)
    em = load_evidence(p)
    eid = args.evidence_id
    if eid in manifest.get("evidence_ids", []) or any(e.get("evidence_id") == eid for e in em.get("evidence", [])):
        raise SystemExit(f"Evidence ID already registered and immutable: {eid}")
    obj = {
        "evidence_id": eid,
        "kind": kind_override or args.kind,
        "source_system": args.source_system,
        "source_identifier": args.source_identifier,
        "occurred_at": args.occurred_at or now_iso(),
        "registered_at": now_iso(),
        "sha256": args.sha256,
        "summary": args.summary,
    }
    em["case_capsule_id"] = manifest["case_capsule_id"]
    em.setdefault("evidence", []).append(obj)
    save_json(p["evidence"], em)
    manifest.setdefault("evidence_ids", []).append(eid)
    event(manifest, p, "evidence.registered", "source-system", args.source_system, outputs=[eid])
    write_manifest(manifest, p)
    refresh_current_state(root)
    print(json.dumps(obj, indent=2))

def cmd_ingest_referral(args):
    register_evidence(Path(args.path), args, kind_override="referral")

def cmd_register_evidence(args):
    register_evidence(Path(args.path), args)

def assertion_filename(assertion_id: str, type_: str) -> str:
    safe = "".join(c for c in assertion_id if c.isalnum() or c in "-_.")
    return f"{type_}.{safe}.json"

def ensure_evidence_refs(manifest: dict, refs: list[str]) -> None:
    missing = [x for x in refs if x not in set(manifest.get("evidence_ids", []))]
    if missing:
        raise SystemExit("Unknown evidence references: " + ", ".join(missing))

def cmd_run_classification(args):
    root = Path(args.path)
    manifest, p = must_capsule(root)
    refs = args.evidence_ref or []
    ensure_evidence_refs(manifest, refs)
    if args.assertion_id in manifest.get("assertion_ids", []):
        raise SystemExit(f"Assertion already exists: {args.assertion_id}")

    supersedes = args.supersedes or []
    for old_id in supersedes:
        old_fp, old = find_assertion(p, old_id)
        old["status"] = "superseded"
        old["superseded_by"] = args.assertion_id
        save_json(old_fp, old)

    a = {
        "schema_version": VERSION,
        "assertion_id": args.assertion_id,
        "case_capsule_id": manifest["case_capsule_id"],
        "type": "classification",
        "code_system": args.code_system,
        "code": args.value,
        "value": args.value,
        "human_readable": args.human_readable,
        "status": "pending-confirmation",
        "confidence": args.confidence,
        "uncertainty": args.uncertainty,
        "evidence_refs": refs,
        "derived_from_assertion_refs": [],
        "producer": {
            "actor_type": "skill",
            "actor_id": args.skill_name,
            "skill_name": args.skill_name,
            "skill_version": args.skill_version,
            "model_provider": args.model_provider,
            "model_id": args.model_id,
            "runtime": args.runtime,
        },
        "created_at": now_iso(),
        "confirmed_at": None,
        "confirmed_by": None,
        "supersedes": supersedes,
        "superseded_by": None,
        "provenance_event_refs": [],
        "extensions": {"requires_confirmation": True},
    }
    fp = p["skills"]/assertion_filename(args.assertion_id, "classification")
    save_json(fp, a)
    manifest.setdefault("assertion_ids", []).append(args.assertion_id)
    event(manifest, p, "skill.executed", "skill", args.skill_name,
          inputs=refs + supersedes, outputs=[args.assertion_id],
          execution={
              "skill_name": args.skill_name,
              "skill_version": args.skill_version,
              "model_provider": args.model_provider,
              "model_id": args.model_id,
              "runtime": args.runtime,
              "configuration_digest": None,
              "status": "succeeded",
          })
    event(manifest, p, "assertion.created", "skill", args.skill_name,
          inputs=refs, outputs=[args.assertion_id])
    for old_id in supersedes:
        event(manifest, p, "assertion.superseded", "system-service", "case-capsule-runtime",
              targets=[old_id], outputs=[args.assertion_id], reason="Explicit supersession from new classification assertion.")
    manifest["current_state_version"] = manifest.get("current_state_version", 0) + 1
    write_manifest(manifest, p)
    refresh_current_state(root)
    print(json.dumps(a, indent=2))

def change_assertion_status(root: Path, assertion_id: str, new_status: str, actor_id: str, role: str, reason=None):
    manifest, p = must_capsule(root)
    fp, a = find_assertion(p, assertion_id)
    if new_status == "confirmed":
        if a.get("status") in ("superseded", "rejected", "entered-in-error"):
            raise SystemExit(f"Cannot confirm assertion in status {a.get('status')}")
        a["status"] = "confirmed"
        a["confirmed_at"] = now_iso()
        a["confirmed_by"] = actor_id
        et = "assertion.confirmed"
    else:
        a["status"] = "rejected"
        et = "assertion.rejected"
    save_json(fp, a)
    event(manifest, p, et, "clinician", actor_id, role=role, targets=[assertion_id], reason=reason)
    manifest["current_state_version"] = manifest.get("current_state_version", 0) + 1
    write_manifest(manifest, p)
    refresh_current_state(root)
    print(json.dumps(a, indent=2))

def cmd_confirm(args):
    change_assertion_status(Path(args.path), args.assertion_id, "confirmed", args.actor_id, args.role, args.reason)

def cmd_reject(args):
    change_assertion_status(Path(args.path), args.assertion_id, "rejected", args.actor_id, args.role, args.reason)

def generic_assertion(root: Path, args, type_: str, value: Any, actor_type="clinician", actor_id=None):
    manifest, p = must_capsule(root)
    refs = args.evidence_ref or []
    ensure_evidence_refs(manifest, refs)
    if args.assertion_id in manifest.get("assertion_ids", []):
        raise SystemExit(f"Assertion already exists: {args.assertion_id}")
    a = {
        "schema_version": VERSION,
        "assertion_id": args.assertion_id,
        "case_capsule_id": manifest["case_capsule_id"],
        "type": type_,
        "code_system": getattr(args, "code_system", None),
        "code": getattr(args, "code", None),
        "value": value,
        "human_readable": getattr(args, "human_readable", None),
        "status": "confirmed" if actor_type == "clinician" else "pending-confirmation",
        "confidence": None,
        "uncertainty": None,
        "evidence_refs": refs,
        "derived_from_assertion_refs": [],
        "producer": {
            "actor_type": actor_type,
            "actor_id": actor_id or "case-capsule-runtime",
            "skill_name": None,
            "skill_version": None,
            "model_provider": None,
            "model_id": None,
            "runtime": "capsule_runtime.py",
        },
        "created_at": now_iso(),
        "confirmed_at": now_iso() if actor_type == "clinician" else None,
        "confirmed_by": actor_id if actor_type == "clinician" else None,
        "supersedes": [],
        "superseded_by": None,
        "provenance_event_refs": [],
        "extensions": {},
    }
    fp = p["skills"]/assertion_filename(args.assertion_id, type_)
    save_json(fp, a)
    manifest.setdefault("assertion_ids", []).append(args.assertion_id)
    event(manifest, p, "assertion.created", actor_type, actor_id or "case-capsule-runtime",
          inputs=refs, outputs=[args.assertion_id], role=getattr(args, "role", None))
    if actor_type == "clinician":
        event(manifest, p, "assertion.confirmed", "clinician", actor_id,
              targets=[args.assertion_id], role=getattr(args, "role", None))
    manifest["current_state_version"] = manifest.get("current_state_version", 0) + 1
    write_manifest(manifest, p)
    refresh_current_state(root)
    return a

def cmd_record_surgery(args):
    value = {
        "procedure": args.procedure,
        "performed_at": args.performed_at or now_iso(),
        "device_class": args.device_class,
        "intraoperative_event_summary": args.intraoperative_event_summary,
        "postoperative_plan": args.postoperative_plan,
    }
    a = generic_assertion(Path(args.path), args, "surgical-event", value,
                          actor_type="clinician", actor_id=args.actor_id)
    print(json.dumps(a, indent=2))

def cmd_record_event(args):
    value = json.loads(args.value_json)
    actor_type = "clinician" if args.actor_id else "skill"
    actor_id = args.actor_id or args.skill_name or "event-recorder"
    a = generic_assertion(Path(args.path), args, "outcome-classification", value,
                          actor_type=actor_type, actor_id=actor_id)
    print(json.dumps(a, indent=2))

def cmd_record_outcome(args):
    root = Path(args.path)
    manifest, p = must_capsule(root)
    refs = args.evidence_ref or []
    ensure_evidence_refs(manifest, refs)
    if args.outcome_id in manifest.get("outcome_observation_ids", []):
        raise SystemExit(f"Outcome observation already exists: {args.outcome_id}")
    try:
        value = json.loads(args.value)
    except json.JSONDecodeError:
        value = args.value
    o = {
        "schema_version": VERSION,
        "outcome_observation_id": args.outcome_id,
        "case_capsule_id": manifest["case_capsule_id"],
        "category": args.category,
        "measure": args.measure,
        "code_system": args.code_system,
        "code": args.code,
        "value": value,
        "unit": args.unit,
        "observed_at": args.observed_at or now_iso(),
        "timepoint_label": args.timepoint,
        "source_type": args.source_type,
        "evidence_refs": refs,
        "instrument": args.instrument,
        "baseline_ref": args.baseline_ref,
        "intervention_refs": args.intervention_ref or [],
        "provenance_event_refs": [],
        "extensions": {},
    }
    outcomes = load_outcomes(p)
    outcomes.append(o)
    save_json(p["outcomes"], outcomes)
    manifest.setdefault("outcome_observation_ids", []).append(args.outcome_id)
    actor_id = args.actor_id or args.source_type
    event(manifest, p, "outcome.recorded",
          "clinician" if args.actor_id else "system-service",
          actor_id, inputs=refs, outputs=[args.outcome_id], role=args.role)
    manifest["current_state_version"] = manifest.get("current_state_version", 0) + 1
    write_manifest(manifest, p)
    refresh_current_state(root)
    print(json.dumps(o, indent=2))

def integrity(root: Path) -> dict:
    errors, warnings, info = [], [], []
    try:
        manifest, p = must_capsule(root)
    except Exception as e:
        return {"ok": False, "errors": [str(e)], "warnings": [], "info": []}
    try:
        em = load_evidence(p)
    except Exception as e:
        errors.append(f"Malformed evidence manifest: {e}")
        em = {"evidence":[]}
    try:
        outcomes = load_outcomes(p)
    except Exception as e:
        errors.append(f"Malformed outcomes: {e}")
        outcomes = []
    assertions = load_assertions(p)
    eids = [e.get("evidence_id") for e in em.get("evidence", [])]
    aids = [a.get("assertion_id") for _, a in assertions]
    oids = [o.get("outcome_observation_id") for o in outcomes]

    def dup(xs):
        return sorted({x for x in xs if x is not None and xs.count(x) > 1})
    if dup(eids): errors.append(f"Duplicate evidence IDs: {dup(eids)}")
    if dup(aids): errors.append(f"Duplicate assertion IDs: {dup(aids)}")
    if dup(oids): errors.append(f"Duplicate outcome IDs: {dup(oids)}")

    eset, aset = set(eids), set(aids)
    for fp, a in assertions:
        for r in a.get("evidence_refs", []):
            if r not in eset:
                errors.append(f"{a.get('assertion_id')} references missing evidence {r}")
        for r in a.get("supersedes", []):
            if r not in aset:
                errors.append(f"{a.get('assertion_id')} supersedes missing assertion {r}")
        if a.get("status") == "confirmed" and not a.get("confirmed_by"):
            errors.append(f"{a.get('assertion_id')} is confirmed without confirmed_by")
        if a.get("superseded_by") and a.get("status") != "superseded":
            errors.append(f"{a.get('assertion_id')} has superseded_by but status={a.get('status')}")

    for o in outcomes:
        for r in o.get("evidence_refs", []):
            if r not in eset:
                errors.append(f"{o.get('outcome_observation_id')} references missing evidence {r}")

    for label, inv, actual in [
        ("evidence", set(manifest.get("evidence_ids", [])), eset),
        ("assertion", set(manifest.get("assertion_ids", [])), aset),
        ("outcome", set(manifest.get("outcome_observation_ids", [])), set(oids)),
    ]:
        if inv != actual:
            errors.append(f"Manifest {label} inventory drift: manifest={sorted(inv)} actual={sorted(actual)}")

    # conflicting confirmed classifications by code system
    active_cls = {}
    for _, a in assertions:
        if a.get("type") == "classification" and a.get("status") == "confirmed" and not a.get("superseded_by"):
            key = a.get("code_system") or "unspecified"
            active_cls.setdefault(key, []).append(a.get("assertion_id"))
    for key, ids in active_cls.items():
        if len(ids) > 1:
            warnings.append(f"Multiple active confirmed classifications for {key}: {ids}")

    # parse provenance
    known = set(eids) | set(aids) | set(oids) | {manifest.get("case_capsule_id")}
    if p["events"].exists():
        for lineno, line in enumerate(p["events"].read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                e = json.loads(line)
            except Exception as ex:
                errors.append(f"Malformed provenance JSONL at line {lineno}: {ex}")
                continue
            for field in ("target_refs","input_refs","output_refs"):
                for r in e.get(field, []):
                    # historical event can reference the provenance operation itself indirectly;
                    # only report unknown object refs as warning.
                    if r not in known:
                        warnings.append(f"Provenance line {lineno} {field} unknown ref: {r}")

    if not outcomes:
        info.append("No outcome observations recorded yet.")
    pending = [a["assertion_id"] for _,a in assertions if a.get("status") == "pending-confirmation"]
    if pending:
        warnings.append(f"Assertions pending human confirmation: {pending}")

    return {"ok": not errors, "errors": errors, "warnings": warnings, "info": info}

def cmd_integrity(args):
    result = integrity(Path(args.path))
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["ok"] else 2)

def cmd_current(args):
    state = refresh_current_state(Path(args.path))
    print(json.dumps(state, indent=2))

def add_common_evidence_args(sp, include_kind=True):
    sp.add_argument("path")
    sp.add_argument("--evidence-id", required=True)
    if include_kind:
        sp.add_argument("--kind", required=True)
    sp.add_argument("--source-system", required=True)
    sp.add_argument("--source-identifier", required=True)
    sp.add_argument("--occurred-at")
    sp.add_argument("--sha256")
    sp.add_argument("--summary")

def parser():
    p = argparse.ArgumentParser(description="ORTHO-X Case Capsule reference runtime")
    p.add_argument("--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="command", required=True)

    sp=sub.add_parser("bootstrap"); sp.add_argument("path"); sp.add_argument("--case-id", required=True); sp.add_argument("--patient-ref"); sp.set_defaults(func=cmd_bootstrap)
    sp=sub.add_parser("ingest-referral"); add_common_evidence_args(sp, False); sp.set_defaults(func=cmd_ingest_referral)
    sp=sub.add_parser("register-evidence"); add_common_evidence_args(sp, True); sp.set_defaults(func=cmd_register_evidence)

    sp=sub.add_parser("run-classification")
    sp.add_argument("path"); sp.add_argument("--assertion-id", required=True); sp.add_argument("--value", required=True)
    sp.add_argument("--code-system", default="AO/OTA"); sp.add_argument("--evidence-ref", action="append", required=True)
    sp.add_argument("--skill-name", default="ao-ota-classification"); sp.add_argument("--skill-version", default="0.1.0")
    sp.add_argument("--model-provider"); sp.add_argument("--model-id"); sp.add_argument("--runtime")
    sp.add_argument("--confidence", type=float); sp.add_argument("--uncertainty"); sp.add_argument("--human-readable")
    sp.add_argument("--supersedes", action="append"); sp.set_defaults(func=cmd_run_classification)

    for name, func in [("confirm-assertion",cmd_confirm),("reject-assertion",cmd_reject)]:
        sp=sub.add_parser(name); sp.add_argument("path"); sp.add_argument("--assertion-id", required=True)
        sp.add_argument("--actor-id", required=True); sp.add_argument("--role", required=True); sp.add_argument("--reason"); sp.set_defaults(func=func)

    sp=sub.add_parser("record-surgery")
    sp.add_argument("path"); sp.add_argument("--assertion-id", required=True); sp.add_argument("--evidence-ref", action="append", required=True)
    sp.add_argument("--actor-id", required=True); sp.add_argument("--role", default="surgeon")
    sp.add_argument("--procedure", required=True); sp.add_argument("--performed-at"); sp.add_argument("--device-class")
    sp.add_argument("--intraoperative-event-summary"); sp.add_argument("--postoperative-plan"); sp.add_argument("--human-readable")
    sp.set_defaults(func=cmd_record_surgery)

    sp=sub.add_parser("record-event")
    sp.add_argument("path"); sp.add_argument("--assertion-id", required=True); sp.add_argument("--evidence-ref", action="append", required=True)
    sp.add_argument("--value-json", required=True); sp.add_argument("--actor-id"); sp.add_argument("--role", default="clinician")
    sp.add_argument("--skill-name", default="surgical-site-outcomes"); sp.add_argument("--human-readable")
    sp.set_defaults(func=cmd_record_event)

    sp=sub.add_parser("record-outcome")
    sp.add_argument("path"); sp.add_argument("--outcome-id", required=True); sp.add_argument("--category", required=True)
    sp.add_argument("--measure", required=True); sp.add_argument("--value", required=True); sp.add_argument("--unit")
    sp.add_argument("--observed-at"); sp.add_argument("--timepoint"); sp.add_argument("--source-type", required=True)
    sp.add_argument("--evidence-ref", action="append", default=[]); sp.add_argument("--instrument")
    sp.add_argument("--baseline-ref"); sp.add_argument("--intervention-ref", action="append", default=[])
    sp.add_argument("--code-system"); sp.add_argument("--code"); sp.add_argument("--actor-id"); sp.add_argument("--role")
    sp.set_defaults(func=cmd_record_outcome)

    sp=sub.add_parser("integrity-check"); sp.add_argument("path"); sp.set_defaults(func=cmd_integrity)
    sp=sub.add_parser("current-state"); sp.add_argument("path"); sp.set_defaults(func=cmd_current)
    return p

def main():
    args = parser().parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
