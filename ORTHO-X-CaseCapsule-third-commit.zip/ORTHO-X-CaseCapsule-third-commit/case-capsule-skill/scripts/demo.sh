#!/usr/bin/env bash
set -euo pipefail

RUNTIME="${1:-case-capsule-skill/scripts/capsule_runtime.py}"
CAPSULE="${2:-/tmp/ortho-x-demo-capsule}"

rm -rf "$CAPSULE"

python3 "$RUNTIME" bootstrap "$CAPSULE" --case-id cc-demo-001 --patient-ref patient-demo-001

python3 "$RUNTIME" ingest-referral "$CAPSULE" \
  --evidence-id ev-referral-001 \
  --source-system synthetic-ehr \
  --source-identifier SYN-REF-001 \
  --summary "Synthetic referral after fall with right hip pain."

python3 "$RUNTIME" register-evidence "$CAPSULE" \
  --evidence-id ev-xray-001 \
  --kind dicom-study-reference \
  --source-system synthetic-pacs \
  --source-identifier SYN-XR-001 \
  --summary "Synthetic AP pelvis and lateral hip."

python3 "$RUNTIME" run-classification "$CAPSULE" \
  --assertion-id as-aoota-001 \
  --value 31-A2.3 \
  --code-system AO/OTA \
  --evidence-ref ev-xray-001 \
  --skill-name ao-ota-classification \
  --skill-version 0.1.0 \
  --model-provider synthetic \
  --model-id synthetic-reference-model \
  --runtime demo \
  --confidence 0.94 \
  --human-readable "Synthetic AO/OTA classification."

python3 "$RUNTIME" confirm-assertion "$CAPSULE" \
  --assertion-id as-aoota-001 \
  --actor-id surgeon-demo-001 \
  --role surgeon

python3 "$RUNTIME" integrity-check "$CAPSULE"
python3 "$RUNTIME" current-state "$CAPSULE"
