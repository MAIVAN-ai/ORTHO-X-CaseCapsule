import json
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
RUNTIME = HERE / "scripts" / "capsule_runtime.py"

class CapsuleRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp()) / "capsule"

    def tearDown(self):
        shutil.rmtree(self.tmp.parent, ignore_errors=True)

    def invoke(self, *args, ok=True):
        cp = subprocess.run(["python3", str(RUNTIME), *map(str,args)], capture_output=True, text=True)
        if ok and cp.returncode != 0:
            self.fail(f"command failed: {cp.stderr}\n{cp.stdout}")
        return cp

    def test_bootstrap_ingest_classify_confirm_integrity(self):
        self.invoke("bootstrap", self.tmp, "--case-id", "cc-test-001")
        self.invoke("ingest-referral", self.tmp, "--evidence-id", "ev-r-1",
                 "--source-system", "test-ehr", "--source-identifier", "R1",
                 "--summary", "synthetic")
        self.invoke("register-evidence", self.tmp, "--evidence-id", "ev-x-1",
                 "--kind", "dicom-study-reference", "--source-system", "test-pacs",
                 "--source-identifier", "X1")
        self.invoke("run-classification", self.tmp, "--assertion-id", "as-c-1",
                 "--value", "31-A2.3", "--evidence-ref", "ev-x-1")
        state = json.loads(self.invoke("current-state", self.tmp).stdout)
        self.assertEqual(state["pending_assertions"][0]["assertion_id"], "as-c-1")
        self.invoke("confirm-assertion", self.tmp, "--assertion-id", "as-c-1",
                 "--actor-id", "surgeon-test", "--role", "surgeon")
        check = json.loads(self.invoke("integrity-check", self.tmp).stdout)
        self.assertTrue(check["ok"])
        state = json.loads(self.invoke("current-state", self.tmp).stdout)
        ids = [x["assertion_id"] for x in state["accepted_assertions"]]
        self.assertIn("as-c-1", ids)

    def test_evidence_is_immutable_by_id(self):
        self.invoke("bootstrap", self.tmp, "--case-id", "cc-test-002")
        self.invoke("register-evidence", self.tmp, "--evidence-id", "ev-x",
                 "--kind", "dicom", "--source-system", "pacs", "--source-identifier", "1")
        cp = self.invoke("register-evidence", self.tmp, "--evidence-id", "ev-x",
                      "--kind", "dicom", "--source-system", "pacs", "--source-identifier", "2", ok=False)
        self.assertNotEqual(cp.returncode, 0)
        self.assertIn("immutable", cp.stderr)

    def test_supersession_preserves_old_assertion(self):
        self.invoke("bootstrap", self.tmp, "--case-id", "cc-test-003")
        self.invoke("register-evidence", self.tmp, "--evidence-id", "ev-x",
                 "--kind", "dicom", "--source-system", "pacs", "--source-identifier", "1")
        self.invoke("run-classification", self.tmp, "--assertion-id", "as-old",
                 "--value", "31-A2.2", "--evidence-ref", "ev-x")
        self.invoke("run-classification", self.tmp, "--assertion-id", "as-new",
                 "--value", "31-A2.3", "--evidence-ref", "ev-x", "--supersedes", "as-old")
        files = list((self.tmp/"skills").glob("*.json"))
        by_id = {json.loads(f.read_text())["assertion_id"]: json.loads(f.read_text()) for f in files}
        self.assertIn("as-old", by_id)
        self.assertEqual(by_id["as-old"]["status"], "superseded")
        self.assertEqual(by_id["as-old"]["superseded_by"], "as-new")

if __name__ == "__main__":
    unittest.main()
