# OrthoFlow Runtime Integration

## Reference transaction pattern

An ORTHO-X OrthoFlow node should treat a Case Capsule update as a small transaction:

```text
1. Resolve Case Capsule
2. Register new authoritative evidence
3. Invoke relevant OrthoSkill
4. Validate structured assertion
5. Append assertion
6. Append provenance
7. Request human confirmation if required
8. Refresh current-state projection
9. Integrity check
10. Continue workflow
```

## Example pseudo-agent exchange

```text
User/OrthoFlow: ingest referral
Case Capsule Skill: evidence registered as ev-referral-001

OrthoFlow: register imaging
Case Capsule Skill: imaging reference registered as ev-xray-001

OrthoFlow → AO/OTA OrthoSkill:
  classify target anatomy using ev-xray-001

AO/OTA OrthoSkill → OrthoFlow:
  proposed assertion:
    value: 31-A2.3
    confidence: 0.94
    evidence_refs: [ev-xray-001]
    requires_confirmation: true

OrthoFlow → Case Capsule Skill:
  persist classification

Case Capsule Skill:
  assertion as-aoota-001 = pending-confirmation

OrthoFlow → surgeon:
  confirm / modify / reject?

Surgeon:
  confirm

Case Capsule Skill:
  assertion.confirmed appended
```

## Production adapter boundary

The file runtime can later be replaced by:
- FHIR-backed persistence
- SQL/event store
- graph database
- hospital-local MCP service
- HPE/NVIDIA private-cloud runtime
- other hospital-controlled adapters

without changing the conceptual Skill contract.
